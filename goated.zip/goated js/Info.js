import React from 'react'
import {Link} from 'react-router-dom'
function Info() {
  return (
    <React.Fragment>
        <body className="bodyI">
                <div className="side-menuI">
            <ul className="usi">
                <li className="usi"><img className="usi"src="assets/img/7632690_dashboard_graph_analytics_report_icon.png" alt="" />&nbsp;<span><Link to="/Dashboard">Dashboard</Link></span></li>
                <li className="usi"><img className="usi" src="assets/img/bills_cash.png" alt="" />&nbsp;<span><Link to="/About">Pay Bills</Link></span></li>
                <li className="usi"><img className="usi" src="assets/img/user_icon.png" alt="" />&nbsp;<span><Link to="/Profile">Profile Update</Link></span></li>
                <li className="usi"><img className="usi" src="assets/img/3440922_bag_basket_cart_ecommerce_remove_icon.png" alt="" />&nbsp;<span><Link to="/About">Purchase Book</Link></span></li>
                <li className="usi"><img className="usi" src="assets/img/history_order_icon.png" alt="" />&nbsp;<span><Link to="/History">Purchase History</Link></span></li>
                <li className="usi" style={{ color: `rgb(${197, 17, 44})` }} ><img className="usi" src="assets/img/374629_card_contact_info_sketch_sketchy_icon.png" alt="" />&nbsp;<span><Link to="/Info">User info</Link></span> </li>
                <li className="usi"><img className="usi" src="assets/img/28363_door_exit_logout_mail_out_icon.png" alt="" />&nbsp; <span><Link to="/Home">Log out</Link></span></li>
                
            </ul>
        </div> 
    
        <div className="containerI" />
            <div className="headerI">
                <div className="navI">
                    <div className="searchI">
                        <input className="usi" type="text" placeholder="search" />
                        <button className="usi" type="submit"><img src="assets/img/search_icon.png" alt="" /></button>
                    </div>
                    <div className="userI">
                        <a href="f.com" className="btnI">Add new</a>
                        <img className="usi" src="assets/img/3643784_bell_notification_notify_reminder_ring_icon.png" alt="" />
                        <div className="img-caseI">
                            <img className="usi" src="assets/img/user_icon.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>
    
    
            <link className="usi" href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
    <div className="container emp-profileI">
                <form className="usi" method="post">
                    <div className="rowI">
                        <div className="col-md-4">
                            <div className="profile-imgI">
                                <img  className="usi" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS52y5aInsxSm31CvHOFHWujqUx_wWTS9iM6s7BAm21oEN_RiGoog" alt=""/>
                                <div className="file btn btn-lg btn-primary">
                                    Change Photo
                                    <input className="usi" type="file" name="file"/>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="profile-headI">
                                        <h5 className="usi">
                                            Feranmi Timi
                                        </h5>
                                        <h6 className="usi">
                                            Pathtopro Reader
                                        </h6>
                                        <p className="proile-rating">Rank: <span>8/10</span></p>
                                <ul className="nav nav-tabsI" id="myTab" role="tablist">
                                    <li className="nav-itemI">
                                        <a className="nav-link activeI" id="home-tab" data-toggle="tab" href="f.com" role="tab" aria-controls="home" aria-selected="true">Info</a>
                                    </li>
                              
                                </ul>
                            </div>
                        </div>
                        <div className="col-md-2">
                            <input type="submit" className="profile-edit-btnI" name="btnAddMore" value="Upadte Profile" />
                        </div>
                    </div>
                        <div className="col-md-8">
                            <div className="tab-content profile-tabI" id="myTabContent">
                                <div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <label>User Id</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">Feranmi123</p>
                                                </div>
                                                <div className="col-md-6">
                                                    <label className="usi">Surname</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">Feranmi</p>
                                                </div>
                                            </div>
                                            <div className="rowI">
                                                <div className="col-md-6">
                                                    <label className="usi"> Other Names</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">Peter Timi</p>
                                                </div>
                                            </div>
                                            <div className="rowI">
                                                <div className="col-md-6">
                                                    <label className="usi">Email</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">Feranmitimi@gmail.com</p>
                                                </div>
                                            </div>
                                            <div className="rowI">
                                                <div className="col-md-6">
                                                    <label className="usi">Phone</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">123 456 7890</p>
                                                </div>
                                            </div>
                                            <div className="rowI">
                                                <div className="col-md-6">
                                                    <label className="usi">Profession</label>
                                                </div>
                                                <div className="col-md-6">
                                                    <p className="usi">Web Developer and Designer</p>
                                                </div>
                                            </div>
                  </div>
                  </div>
                  </div>            
                </form>           
            </div>
            </body>
    </React.Fragment>
  )
}

export default Info