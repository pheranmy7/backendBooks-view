import React from 'react'
import {Link} from 'react-router-dom' 
import {useForm} from 'react-hook-form';
//import { useState } from 'react';
import axios from 'axios';
const url = 'http://localhost:4001/app/Sign';

function Sign() {
  
  const onSubmit = (data) => { 
    console.log(data);
    reset();
  };
       
  const{
    register,
    handleSubmit,
   formState: { errors },
    reset,
    trigger,
   // watch,
   } = useForm();

const onError = (errors) => {
  console.log(errors);
};

//console.log(watch());

  return (
    <React.Fragment>
      <body className="bodyS">
    <div className="signinS">
        <form className="siI" onSubmit={handleSubmit (onSubmit, onError)}>
          <h2 className="siI">Sign In</h2>                                                                                                                                             
          <input className={`siI ${errors.Username && "Invalid"}`} type="text" name="Username" placeholder="Enter Username" 
           {...register("Username", {required: 'Username is required', 
           pattern: {
            value: /^[a-z]*$/,
            message: "Only letters are allowed"
           },
          })}
          onKeyUp={() => {
            trigger("Username");
          }}
          />           
           {errors.Username && (<small>{errors.Username.message}</small>)}

          <input className={`siI ${errors.Password && "Invalid"}`} type="text" name="Password" placeholder="Enter Password"
           {...register("Password", {required: 'Password is required',
           minLength: {
            value: 10,
            message: "Minimum Required length is 10"
           },
          })} 
          onKeyUp={() => {
            trigger("Password");
          }}
          />
            {errors.Password && (<small>{errors.Password.message}</small>)}

          <p className="siI" style={{textAlign: "left"}}><input type="checkbox" style= {{width: "15px height: 14px"}} />I agree with the <Link to= "/Privacy">Terms</Link></p>
          <button className="btnSI">Sign In</button>
        </form>
      </div>
      </body>
    </React.Fragment>
  )
}

export default Sign